import sys
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin

from resume import set as resume_set, clear as resume_clear, all as resume_all
from identity import load_identity

HANDLE = int(sys.argv[1])
ARGS = sys.argv[2]

JELLYFIN_HOST = "http://192.168.10.122:8096"
API_KEY = "1e484ab768c0400a97572c3d31ece3c0"
CLIENT = "batclan-kodi"

IDENTITY = load_identity()
USER_ID = IDENTITY["jellyfin_user_id"]
VIEWER = IDENTITY["viewer"]

LIB_MOVIES = "f137a2dd21bbc1b99aa5c0f6bf02a805"
LIB_TV = "4514ec850e5ad0c47b58444e17b6346c"
LIB_KIDS_MOVIES = "384bb658bdd82344138c376d0e4945c0"
LIB_KIDS_TV = "f59d130de19731a61863f59d47783782"

HEADERS = {
    "X-Emby-Token": API_KEY,
    "X-Emby-Client": CLIENT
}

_KIDS_SERIES_CACHE = None
_ITEM_INFO_CACHE = {}

def jellyfin_get(path):
    req = urllib.request.Request(JELLYFIN_HOST + path, headers=HEADERS)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

def plugin_url(params):
    return "plugin://plugin.video.batclan/?" + urllib.parse.urlencode(params)

def item_art(item_id):
    return f"{JELLYFIN_HOST}/Items/{item_id}/Images/Primary?api_key={API_KEY}"

def _item_info(item_id):
    if item_id in _ITEM_INFO_CACHE:
        return _ITEM_INFO_CACHE[item_id]

    info = jellyfin_get(
        f"/Users/{USER_ID}/Items/{item_id}"
        f"?Fields=Overview,Genres,ProductionYear,CommunityRating,Studios,"
        f"RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName,Type,UserData"
    )
    _ITEM_INFO_CACHE[item_id] = info
    return info

def _apply_metadata(li, info, mediatype):
    video = {
        "title": info.get("Name"),
        "plot": info.get("Overview"),
        "year": info.get("ProductionYear"),
        "genre": info.get("Genres"),
        "rating": info.get("CommunityRating"),
        "studio": [s.get("Name") for s in info.get("Studios", [])],
        "mediatype": mediatype,
    }

    if info.get("RunTimeTicks"):
        video["duration"] = int(info["RunTimeTicks"] / 10_000_000)

    if mediatype == "episode":
        video["season"] = info.get("ParentIndexNumber")
        video["episode"] = info.get("IndexNumber")
        video["tvshowtitle"] = info.get("SeriesName")

    li.setInfo("video", video)

def add_playable(item_id):
    info = _item_info(item_id)
    t = (info.get("Type") or "video").lower()

    label = info.get("Name", item_id)
    if t == "movie" and info.get("ProductionYear"):
        label = f"{label} ({info['ProductionYear']})"
    elif t == "episode":
        s = info.get("ParentIndexNumber")
        e = info.get("IndexNumber")
        if s is not None and e is not None:
            label = f"S{int(s):02d}E{int(e):02d} – {label}"

    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")

    art = item_art(item_id)
    li.setArt({"poster": art, "thumb": art, "fanart": art})

    _apply_metadata(li, info, t)

    xbmcplugin.addDirectoryItem(
        HANDLE,
        plugin_url({"action": "play", "item": item_id}),
        li,
        False
    )

def root():
    for label, action in [
        ("Next Up", "continue_watching"),
        ("Kids Next Up", "continue_watching_kids"),
        ("Finish Up", "finish_up_adult"),
        ("Kids Finish Up", "finish_up_kids"),
        ("Movies", "movies"),
        ("TV", "tv"),
        ("Kids Movies", "kids_movies"),
        ("Kids TV", "kids_tv"),
    ]:
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": action}),
            li,
            True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(parent_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={parent_id}&IncludeItemTypes=Movie&Recursive=true"
    )
    for item in data.get("Items", []):
        add_playable(item["Id"])
    xbmcplugin.endOfDirectory(HANDLE)

def continue_watching():
    data = jellyfin_get(
        f"/Shows/NextUp?UserId={USER_ID}&Limit=50"
    )
    for item in data.get("Items", []):
        add_playable(item["Id"])
    xbmcplugin.endOfDirectory(HANDLE)

def play_item(item_id):
    li = xbmcgui.ListItem(
        path=f"{JELLYFIN_HOST}/Videos/{item_id}/stream?static=true|X-Emby-Token={API_KEY}"
    )
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

params = dict(urllib.parse.parse_qsl(ARGS[1:]))
action = params.get("action")

if action == "continue_watching":
    continue_watching()
elif action == "movies":
    list_movies(LIB_MOVIES)
elif action == "kids_movies":
    list_movies(LIB_KIDS_MOVIES)
elif action == "play" and "item" in params:
    play_item(params["item"])
else:
    root()
