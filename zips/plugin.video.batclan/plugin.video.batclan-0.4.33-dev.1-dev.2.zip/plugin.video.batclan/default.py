import sys
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin

from resume import set as resume_set, clear as resume_clear, all as resume_all
from identity import load_identity

HANDLE = int(sys.argv[1])
ARGS = sys.argv[2]

JELLYFIN_HOST = "http://192.168.10.122:8096"
API_KEY = "1e484ab768c0400a97572c3d31ece3c0"
CLIENT = "batclan-kodi"

IDENTITY = load_identity()
USER_ID = IDENTITY["jellyfin_user_id"]
VIEWER = IDENTITY["viewer"]

LIB_MOVIES = "f137a2dd21bbc1b99aa5c0f6bf02a805"
LIB_TV = "4514ec850e5ad0c47b58444e17b6346c"
LIB_KIDS_MOVIES = "384bb658bdd82344138c376d0e4945c0"
LIB_KIDS_TV = "f59d130de19731a61863f59d47783782"

HEADERS = {
    "X-Emby-Token": API_KEY,
    "X-Emby-Client": CLIENT
}

_KIDS_SERIES_CACHE = None
_ITEM_INFO_CACHE = {}

def jellyfin_get(path):
    req = urllib.request.Request(JELLYFIN_HOST + path, headers=HEADERS)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

def jellyfin_post(path):
    req = urllib.request.Request(JELLYFIN_HOST + path, headers=HEADERS, method="POST")
    urllib.request.urlopen(req).close()

def plugin_url(params):
    return "plugin://plugin.video.batclan/?" + urllib.parse.urlencode(params)

def item_art(item_id):
    return f"{JELLYFIN_HOST}/Items/{item_id}/Images/Primary?api_key={API_KEY}"

def decorate_userdata(li, item):
    ud = item.get("UserData") or {}
    if ud.get("Played"):
        li.setProperty("IsWatched", "true")

    resume_ticks = ud.get("PlaybackPositionTicks") or 0
    runtime_ticks = item.get("RunTimeTicks") or 0

    if resume_ticks > 0 and runtime_ticks > 0 and resume_ticks < runtime_ticks:
        li.setProperty("resumetime", str(resume_ticks // 10_000_000))
        li.setProperty("totaltime", str(runtime_ticks // 10_000_000))

def add_folder(label, params):
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, isFolder=True)

def add_playable(item, params, mediatype):
    name = item.get("Name", "")
    year = item.get("ProductionYear")
    label = f"{name} ({year})" if mediatype == "movie" and year else name

    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": name, "mediatype": mediatype})
    art = item_art(item["Id"])
    li.setArt({"poster": art, "thumb": art, "fanart": art})
    decorate_userdata(li, item)

    xbmcplugin.addDirectoryItem(
        HANDLE,
        plugin_url(params),
        li,
        isFolder=False
    )

def _kids_series_ids():
    global _KIDS_SERIES_CACHE
    if _KIDS_SERIES_CACHE is not None:
        return _KIDS_SERIES_CACHE

    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={LIB_KIDS_TV}"
        f"&IncludeItemTypes=Series"
        f"&Fields=Id"
    )
    _KIDS_SERIES_CACHE = {i["Id"] for i in data.get("Items", [])}
    return _KIDS_SERIES_CACHE

def _item_info(item_id):
    if item_id in _ITEM_INFO_CACHE:
        return _ITEM_INFO_CACHE[item_id]

    try:
        info = jellyfin_get(
            f"/Users/{USER_ID}/Items/{item_id}"
            f"?Fields=ProductionYear,IndexNumber,ParentIndexNumber,SeriesName,SeriesId,ParentId"
        )
    except Exception:
        info = {}

    _ITEM_INFO_CACHE[item_id] = info
    return info

def _is_kids_item(item_id):
    info = _item_info(item_id)
    t = (info.get("Type") or "").lower()

    if t == "movie":
        return info.get("ParentId") == LIB_KIDS_MOVIES

    if t == "episode":
        sid = info.get("SeriesId")
        return sid in _kids_series_ids() if sid else False

    return False

def root():
    add_folder("Next Up", {"action": "continue_watching"})
    add_folder("Kids Next Up", {"action": "continue_watching_kids"})
    add_folder("Finish Up", {"action": "finish_up_adult"})
    add_folder("Kids Finish Up", {"action": "finish_up_kids"})
    add_folder("Movies", {"action": "movies"})
    add_folder("TV", {"action": "tv"})
    add_folder("Kids Movies", {"action": "kids_movies"})
    add_folder("Kids TV", {"action": "kids_tv"})
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(parent_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={parent_id}"
        f"&IncludeItemTypes=Movie"
        f"&Recursive=true"
        f"&Fields=UserData,RunTimeTicks,ProductionYear"
    )
    for item in data.get("Items", []):
        add_playable(item, {"action": "play", "item": item["Id"]}, "movie")
    xbmcplugin.endOfDirectory(HANDLE)

def list_series(parent_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={parent_id}"
        f"&IncludeItemTypes=Series"
        f"&Fields=UserData"
    )
    for item in data.get("Items", []):
        li = xbmcgui.ListItem(label=item.get("Name", ""))
        li.setInfo("video", {"title": item.get("Name", ""), "mediatype": "tvshow"})
        art = item_art(item["Id"])
        li.setArt({"poster": art, "thumb": art, "fanart": art})
        decorate_userdata(li, item)

        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "seasons", "series": item["Id"]}),
            li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def list_seasons(series_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={series_id}"
        f"&IncludeItemTypes=Season"
        f"&Fields=UserData"
    )
    for item in data.get("Items", []):
        li = xbmcgui.ListItem(label=item.get("Name", ""))
        li.setInfo("video", {"title": item.get("Name", ""), "mediatype": "season"})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "episodes", "season": item["Id"]}),
            li,
            isFolder=True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(season_id):
    data = jellyfin_get(
        f"/Users/{USER_ID}/Items"
        f"?ParentId={season_id}"
        f"&IncludeItemTypes=Episode"
        f"&Recursive=true"
        f"&Fields=UserData,RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName,SeriesId"
    )
    for item in data.get("Items", []):
        s = item.get("ParentIndexNumber")
        e = item.get("IndexNumber")
        title = item.get("Name", "")
        label = f"S{int(s):02d}E{int(e):02d} – {title}" if s is not None and e is not None else title

        item2 = dict(item)
        item2["Name"] = label
        add_playable(item2, {"action": "play", "item": item2["Id"]}, "episode")

    xbmcplugin.endOfDirectory(HANDLE)

def continue_watching():
    kids_ids = _kids_series_ids()
    data = jellyfin_get(
        f"/Shows/NextUp"
        f"?UserId={USER_ID}&Limit=50"
        f"&Fields=UserData,RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName,SeriesId"
    )
    for item in data.get("Items", []):
        if item.get("SeriesId") in kids_ids:
            continue

        s = item.get("ParentIndexNumber")
        e = item.get("IndexNumber")
        title = item.get("Name", "")
        series = item.get("SeriesName") or ""
        label = f"{series} — S{int(s):02d}E{int(e):02d} – {title}" if s is not None and e is not None else title

        item2 = dict(item)
        item2["Name"] = label
        add_playable(item2, {"action": "play", "item": item2["Id"]}, "episode")

    xbmcplugin.endOfDirectory(HANDLE)

def continue_watching_kids():
    kids_ids = _kids_series_ids()
    data = jellyfin_get(
        f"/Shows/NextUp"
        f"?UserId={USER_ID}&Limit=50"
        f"&Fields=UserData,RunTimeTicks,IndexNumber,ParentIndexNumber,SeriesName,SeriesId"
    )
    for item in data.get("Items", []):
        if item.get("SeriesId") not in kids_ids:
            continue

        s = item.get("ParentIndexNumber")
        e = item.get("IndexNumber")
        title = item.get("Name", "")
        series = item.get("SeriesName") or ""
        label = f"{series} — S{int(s):02d}E{int(e):02d} – {title}" if s is not None and e is not None else title

        item2 = dict(item)
        item2["Name"] = label
        add_playable(item2, {"action": "play", "item": item2["Id"]}, "episode")

    xbmcplugin.endOfDirectory(HANDLE)

def _show_finish_up(kind):
    xbmcplugin.setContent(HANDLE, "videos")
    rows = resume_all(50, VIEWER)

    for item_id, data in rows:
        if kind == "kids" and not _is_kids_item(item_id):
            continue
        if kind == "adult" and _is_kids_item(item_id):
            continue

        li = xbmcgui.ListItem(label=data["label"])
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": data["label"], "mediatype": data["mediatype"]})
        art = data["art"]
        li.setArt({"poster": art, "thumb": art, "fanart": art})
        li.setProperty("ResumeTime", str(int(data["position"])))
        li.setProperty("TotalTime", str(int(data["total"])))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            plugin_url({"action": "play", "item": item_id}),
            li,
            False
        )

    xbmcplugin.endOfDirectory(HANDLE)

def finish_up_adult():
    _show_finish_up("adult")

def finish_up_kids():
    _show_finish_up("kids")

def play_item(item_id):
    info = _item_info(item_id)

    li = xbmcgui.ListItem(
        path=f"{JELLYFIN_HOST}/Videos/{item_id}/stream?static=true|X-Emby-Token={API_KEY}"
    )
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    p = xbmc.Player()
    m = xbmc.Monitor()

    started = False
    last_pos = 0.0
    total = 0.0

    while not m.abortRequested():
        if p.isPlaying():
            started = True
            last_pos = p.getTime()
            total = p.getTotalTime()
            if m.waitForAbort(0.5):
                break
        else:
            if started:
                break
            if m.waitForAbort(0.1):
                break

    if total > 0:
        if (last_pos / total) >= 0.9:
            resume_clear(item_id, VIEWER)
        else:
            resume_set(
                item_id,
                info.get("Name", item_id),
                item_art(item_id),
                (info.get("Type") or "video").lower(),
                last_pos,
                total,
                VIEWER
            )

params = dict(urllib.parse.parse_qsl(ARGS[1:]))
action = params.get("action")

if action == "continue_watching":
    continue_watching()
elif action == "continue_watching_kids":
    continue_watching_kids()
elif action == "finish_up_adult":
    finish_up_adult()
elif action == "finish_up_kids":
    finish_up_kids()
elif action == "movies":
    list_movies(LIB_MOVIES)
elif action == "tv":
    list_series(LIB_TV)
elif action == "kids_movies":
    list_movies(LIB_KIDS_MOVIES)
elif action == "kids_tv":
    list_series(LIB_KIDS_TV)
elif action == "seasons" and "series" in params:
    list_seasons(params["series"])
elif action == "episodes" and "season" in params:
    list_episodes(params["season"])
elif action == "play" and "item" in params:
    play_item(params["item"])
else:
    root()
